# Contributing

If you're adding support for a new file type, [please follow these steps](.github/pull_request_template.md).
